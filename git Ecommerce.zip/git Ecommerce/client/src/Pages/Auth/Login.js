import React,{useState} from 'react';
import Layout from '../../Components/Layout/Layout.js';
import './AuthStyle.css';
import {toast} from 'react-toastify'
import {useNavigate} from 'react-router-dom'
import axios from 'axios';
import { useAuth } from '../../Context/auth.js';
import { json } from 'express';
const Login = () => {
    
    const [email,setEmail] = useState('');
    const [password,setpassword] = useState('');
    const [auth,setAuth] = useAuth()
    const navigate = useNavigate()

    const handleSubmit= async (e) =>{
        e.preventDefault();
        // toast.success('Register Successfully'); // notification ka liye

        try{
            const res = await axios.post('/api/v1/auth/login',
            {email,password});
            if(res.data.success){
                toast.success(res.data.message)
                setAuth({
                    ...auth,
                    user:res.data.user,
                    token:res.data.token
                })
                localStorage.setItem('auth',json.stringify(res.data))
                navigate('/');
            }else{
                toast.error(res.data.error)
            }
        }catch (error){
            console.log(error);
            toast.error("Something went wrong")
        }
       
    }

    return(
        <Layout>
        <div className='form-container' >
                <h1>Login Form</h1>
                <form onSubmit={handleSubmit}>
                    
                    <div className="mb-3">
                        <input type="Eamil" className="form-control" value ={email} onChange = {(e) => setEmail(e.target.value)} id="exampleInputEmail1" placeholder='Enter Your Eamil' required/>
                        
                    </div>
                    <div className="mb-3">
                        <input type="password" className="form-control" value ={password} onChange = {(e) => setpassword(e.target.value)} id="exampleInputPassword1" placeholder='Enter Your Password' required/>
                    </div>
                    
                    <button type="submit" className="btn btn-primary">Submit</button>
                </form>
            </div>
        </Layout>
    )
};
export default Login;