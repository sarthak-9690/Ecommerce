import React from 'react';
import Layout from '../Components/Layout/Layout.js';

const Policy = () =>{
    return (
        <Layout>
        <h1>Privacy Policy Page</h1>
        </Layout>
    )
};
export default Policy;