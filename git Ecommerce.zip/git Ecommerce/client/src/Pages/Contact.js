import React from 'react';
import Layout from '../Components/Layout/Layout.js';

const Contact = () =>{
    return (
        <Layout>
        <h1>Contact Page</h1>
        </Layout>
    )
};
export default Contact;