
import {Routes, Route} from 'react-router-dom'
import HomePage from './Pages/HomePage.js';
import About from './Pages/About.js';
import Contact from './Pages/Contact.js';
import Policy from './Pages/Policy.js';
import PagenotFound from './Pages/PagenotFound.js';
import Register from './Pages/Auth/Register.js';
import Login from './Pages/Auth/Login.js';


function App() {
  return (
    <>
    <Routes>
      <Route exact path='/' element={<HomePage/>} />
      <Route exact path='/about' element={<About/>} />
      <Route exact path='/contact' element={<Contact/>} />
      <Route exact path='/policy' element={<Policy/>} />
      <Route exact path='*' element={<PagenotFound/>} />
      <Route exact path='/register' element={<Register/>} />
      <Route exact path='/login' element={<Login/>} />

    </Routes>
    </>
  );
}

export default App;
