const path = require('path');
const webpack = require('webpack');
const process = require('process');



module.exports = function override(config){
    const fallback = config.resolve.fallback || {};
    const extensions = config.resolve.extensions || {};

    Object.assign(fallback,{
        zlib: require.resolve("browserify-zlib"),
        querystring: require.resolve("querystring-es3"),
        path: require.resolve("path-browserify"),
        crypto: require.resolve("crypto-browserify"),
        fs:false,
        stream: require.resolve("stream-browserify"),
        http: require.resolve("stream-http"),
        net:false,
        buffer: require.resolve("buffer/"),
        assert: require.resolve("assert/"),
        util: require.resolve("util/"),
        os: require.resolve("os-browserify"),
        url: require.resolve("url/"),
        vm: require.resolve("vm-browserify")
    })

    module.exports = {
        resolve:{
            fallback:{
                process : require.resolve("process/browser"),
                path : require.resolve("path-browserify")
            },
            
            extensions: ['.js', '.jsx', '.json', '.mjs', '.cjs']
        },
    };
    
    config.resolve.fallback = fallback;
    config.resolve.extensions = extensions;

    config.plugins = (config.plugins || []).concat([
        new webpack.ProvidePlugin({
            process:"process/browser",
        }),
    ]);
    return config;
};